// Log that the extension has been loaded
console.log("Button Clicker extension loaded.");

// Declare and initialize variables and constants
const buttonClass = '.set-favorite-btn'; // class name for the favorite button
let buttonClicked = false; // whether a button click is currently in progress
let clickQueue = []; // queue of buttons to click
const MIN_WAIT_INTERVAL = 500; // minimum time to wait between button clicks in milliseconds (0.5 seconds)
const MAX_WAIT_INTERVAL = 1000; // maximum time to wait between button clicks in milliseconds (1 second)
const SCROLL_INTERVAL = 2000; // time to wait between scrolling to next unclicked post in milliseconds (2 seconds)
let scrollIntervalId = null; // ID of the interval used for scrolling to next unclicked post
let currentParentIndex = 0; // index of the current post element being checked for unclicked button
let nextPauseCount = Math.floor(Math.random() * 6) + 5; // number of posts to check before pausing scrolling
let currentPauseCount = 0; // counter for the number of posts checked since the last pause

// Debounce function to limit the number of API requests made
const debounce = (func, wait, immediate) => {
  let timeout;
  return (...args) => { // use rest parameter syntax instead of arguments
    const context = this;
    const later = () => {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };
    const callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
};

// Batched set operation function to prevent overwhelming the API
const batchSet = (keyValues) => {
  const batches = Object.entries(keyValues).reduce(
    (acc, [key, value]) => {
      const batchIndex = acc.length - 1;
      if (acc[batchIndex].length < 100) {
        acc[batchIndex].push({key, value});
      } else {
        acc.push([{key, value}]);
      }
      return acc;
    },
    [[]]
  );

  // Set each batch with a random delay between 1-3 seconds multiplied by the batch index
  batches.forEach((batch, i) => {
    setTimeout(() => {
      chrome.storage.local.set(
        Object.fromEntries(batch),
        () => {
          console.log(
            `Batch ${i + 1} of ${batches.length} set!`
          );
        }
      );
    }, Math.floor(Math.random() * 2000) + 1000 * i);
  });
};

// Function to count the number of times each user's favorite button was clicked
const countClickedFavoriteButtons = () => {
  console.log("Counting clicked favorite buttons...");
  const clickedButtons = document.querySelectorAll(
    `${buttonClass}.m-active`
  );
  clickedButtons.forEach((button) => {
    const postElement = button.closest(".b-post");
    const username = postElement.querySelector(
      ".g-user-username"
    ).textContent.trim();
    const postId = postElement.id;

    // Get the current clickCounts and clickedPostIds from storage
    chrome.storage.local.get(
      ["clickCounts", "clickedPostIds"],
      async ({clickCounts, clickedPostIds}) => {
        clickCounts = clickCounts || {};
        clickedPostIds = clickedPostIds || {};

        if (!clickedPostIds[postId]) {
          // Add the postId to clickedPostIds to mark it as clicked
          clickedPostIds[postId] = true;

          // Debounce the API call to limit the number of requests made
          await debounce(() => {
            console.log("clickedPostIds", clickedPostIds.length);
            batchSet({clickedPostIds});
          }, 1000)();

          clickCounts[username] = (clickCounts[username] || 0) + 1;

          // Debounce the API call to limit the number of requests made
          await debounce(() => {
            console.log("clickCounts", clickCounts.length);
            batchSet({clickCounts});
          }, 1000)();
        }
      }
    );
  });
};

// Function to scroll to the next parent element that has not been clicked
const scrollToNextParent = () => {
  const parents = document.querySelectorAll(".b-post");
  let unlikedPostFound = false;

  while (currentParentIndex < parents.length && !unlikedPostFound) {
    const post = parents[currentParentIndex];
    const button = post.querySelector(buttonClass);
    if (!button.classList.contains("m-active")) {
      unlikedPostFound = true;
      const currentScrollPos = window.scrollY;
      const parentTop =
        post.getBoundingClientRect().top + currentScrollPos;
      window.scrollTo({top: parentTop, behavior: "smooth"});
    }
    currentParentIndex++;
  }

  if (!unlikedPostFound) {
    const currentScrollPos = window.scrollY;
    const bottomScrollPos = document.body.scrollHeight;
    window.scrollTo({top: bottomScrollPos, behavior: "smooth"});
  }

  currentPauseCount++;
  if (currentPauseCount === nextPauseCount) {
    console.log('Pausing scroll for batch set operation.');
    clearInterval(scrollIntervalId);
    scrollIntervalId = null;
    setTimeout(async () => {
      console.log(`Resuming scroll after batch set operation.`);
      currentPauseCount = 0;
      nextPauseCount = Math.floor(Math.random() * 6) + 5;
      scrollIntervalId = setInterval(
        scrollToNextParent,
        SCROLL_INTERVAL
      );

      chrome.storage.local.get(
        ["clickCounts", "clickedPostIds"],
        async ({clickCounts, clickedPostIds}) => {
          clickCounts = clickCounts || {};
          clickedPostIds = clickedPostIds || {};
          await batchSet({clickCounts, clickedPostIds});
        }
      );
    }, Math.floor(Math.random() * 2000) + 1000);
  }
};

// clickButton function to click the favorite button
const clickButton = (button) => {
  if (button && !buttonClicked) {
    buttonClicked = true;
    clickQueue.push(button);
    setTimeout(() => {
      const button = clickQueue.shift();
      button.click();
      buttonClicked = false;

      // Extract the username from the parent b-post element
      const postElement = button.closest(".b-post");
      const username = postElement.querySelector(
        ".g-user-username"
      ).textContent.trim();
      const postId = postElement.id;

      // Check if the post has already been clicked and increase the count
      chrome.storage.local.get(
        ["clickCounts", "clickedPostIds"],
        async ({clickCounts, clickedPostIds}) => {
          clickCounts = clickCounts || {};
          clickedPostIds = clickedPostIds || {};

          if (!clickedPostIds[postId]) {
            clickedPostIds[postId] = true;
            clickCounts[username] = (clickCounts[username] || 0) + 1;

            await chrome.storage.local.set(
              {clickCounts, clickedPostIds}
            );

            console.log(
              `Button clicked for user ${username}! Total clicks: ${
                clickCounts[username]
              }`
            );

            // Increase the lifetime click count and save it to storage
            chrome.storage.local.get(
              "lifetimeClicks",
              async ({lifetimeClicks}) => {
                lifetimeClicks = (lifetimeClicks || 0) + 1;
                await chrome.storage.local.set({
                  lifetimeClicks,
                });
                console.log(
                  `Button clicked! Lifetime clicks: ${lifetimeClicks}`
                );
              }
            );
          } else {
            console.log(
              `Button for post ${postId} has already been clicked.`
            );
          }
        }
      );
    }, Math.floor(Math.random() * (MAX_WAIT_INTERVAL - MIN_WAIT_INTERVAL + 1)) + MIN_WAIT_INTERVAL); // random interval between 0.5 and 1 seconds
  }
};

// IntersectionObserver to detect when the favorite button is in view
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting && !entry.target.classList.contains("m-active")) {
      clickButton(entry.target);
      console.log("Button clicked!");
    }
  });
}, {
  root: null,
  threshold: 0.5,
});

const observeButtons = () => {
  document.querySelectorAll(buttonClass).forEach((button) => {
    if (!button.classList.contains("m-active")) {
      observer.observe(button);
    } else {
      console.log("Button already clicked");
    }
  });
};

// Detect when new elements are added to the DOM
const mutationObserver = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    if (mutation.type === "childList") {
      // observeButtons();
      countClickedFavoriteButtons();
    }
  });
});

mutationObserver.observe(document.body, {
  childList: true,
  subtree: true,
});

chrome.runtime.sendMessage({type: "extensionLoaded"});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "toggle") {
    if (request.enabled) {
      console.log("Button Clicker is enabled");
      observeButtons();
    } else {
      console.log("Button Clicker is disabled");
      document.querySelectorAll(buttonClass).forEach((button) => {
        observer.unobserve(button);
      });
    }
  }

  if (request.type === "idle") {
    if (request.enabled) {
      console.log("Idle mode enabled");
      scrollIntervalId = setInterval(
        scrollToNextParent,
        SCROLL_INTERVAL
      );
    } else {
      console.log("Idle mode disabled");
      clearInterval(scrollIntervalId);
      scrollIntervalId = null;
    }
  }
});

