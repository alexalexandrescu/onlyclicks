document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('toggle');
  const clickCountsElement = document.getElementById('clickCounts');
  const lifetimeClicksElement = document.getElementById('lifetimeClicks');
  const idle = document.getElementById('idle');

  function updateTitle(enabled) {
    const title = document.getElementById('title');
    if (enabled) {
      title.classList.add('enabled');
    } else {
      title.classList.remove('enabled');
    }
  }

  function sendMessageToContentScript(type, enabled) {
    if (type === 'toggle') {
      updateTitle(enabled);
    }

    chrome.storage.sync.set({ [type]: enabled }, () => {
      console.log(`${type} state saved: ${enabled}`);
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, { type, enabled });
      });
    });
  }

  toggle.addEventListener('change', () => {
    sendMessageToContentScript('toggle', toggle.checked);
  });

  idle.addEventListener('change', () => {
    sendMessageToContentScript('idle', idle.checked);
  });

  chrome.storage.sync.get('enabled', ({ enabled }) => {
    toggle.checked = enabled;
    updateTitle(enabled);
    console.log(`Toggle state retrieved: ${enabled}`);
  });

  chrome.storage.sync.get('idle', ({ idle }) => {
    idle.checked = idle;
    console.log(`Idle state retrieved: ${idle}`);
  });

  // Retrieve and display the click counts
  chrome.storage.sync.get(['clickCounts', 'lifetimeClicks'], ({ clickCounts, lifetimeClicks }) => {
    for (const [username, count] of Object.entries(clickCounts || {})) {
      const li = document.createElement('li');
      li.textContent = `${username}: ${count}`;
      clickCountsElement.appendChild(li);
    }
    console.log(`Click counts retrieved:`, clickCounts);

    lifetimeClicksElement.textContent = `Lifetime likes: ${lifetimeClicks || 0}`;
    console.log(`Lifetime clicks retrieved: ${lifetimeClicks || 0}`);
  });

  // Add a delay to make sure the content script is loaded before sending a message
  setTimeout(() => {
    sendMessageToContentScript('toggle', toggle.checked);
    sendMessageToContentScript('idle', idle.checked);
  }, 500);
});
